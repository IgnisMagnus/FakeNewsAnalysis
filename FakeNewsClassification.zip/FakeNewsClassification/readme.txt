Obtained @ :
https://www.kaggle.com/datasets/aadyasingh55/fake-news-classification
Date : 11 Nov 2024